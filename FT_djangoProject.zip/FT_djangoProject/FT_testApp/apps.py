from django.apps import AppConfig


class FtTestappConfig(AppConfig):
    name = 'FT_testApp'
