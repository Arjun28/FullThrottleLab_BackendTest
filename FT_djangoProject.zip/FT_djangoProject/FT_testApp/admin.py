from django.contrib import admin

from .models import Members, Sessions

admin.site.register(Members)
admin.site.register(Sessions)